# BankManagementSystem
The Bank Management System is a Java and MySQL-based desktop application that replicates core banking operations such as deposits, withdrawals, balance enquiry, PIN change, and mini statements. Built using **Java Swing**, **AWT**, and **JDBC**, it ensures smooth database connectivity and real-time transaction management.
